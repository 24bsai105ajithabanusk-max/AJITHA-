// Simple alert for send button

document.querySelector(".contact .btn").addEventListener("click", () => {

  alert("Thank you! Your details are saved.");

});